package com.trailmetrics.auth.security;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.AuthenticatedPrincipalOAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;


@Configuration
public class SecurityConfig {

  private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

  @Value("${spring.security.oauth2.client.registration.strava.client-id}")
  private String clientId;
  @Value("${spring.security.oauth2.client.registration.strava.client-secret}")
  private String clientSecret;
  @Value("${spring.security.oauth2.client.provider.strava.authorization-uri}")
  private String authorizationUri;
  @Value("${spring.security.oauth2.client.provider.strava.token-uri}")
  private String tokenUri;
  @Value("${spring.security.oauth2.client.provider.strava.user-info-uri}")
  private String userInfoUri;
  @Value("${spring.security.oauth2.client.provider.strava.user-name-attribute}")
  private String userNameAttributeName;
  @Value("${spring.security.oauth2.client.registration.strava.client-name}")
  private String clientName;
  @Value("${spring.security.oauth2.client.registration.strava.redirect-uri}")
  private String redirectUri;
  @Value("${spring.security.oauth2.client.registration.strava.scope}")
  private String scope;
  @Value("${app.frontend-url}")
  private String frontendUrl;

  private final JwtUtils jwtUtils;

  private final ApiKeyAuthFilter apiKeyAuthFilter;

  public SecurityConfig(JwtUtils jwtUtils, ApiKeyAuthFilter apiKeyAuthFilter) {
    this.jwtUtils = jwtUtils;
    this.apiKeyAuthFilter = apiKeyAuthFilter;
  }

  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http,
      ClientRegistrationRepository clientRegistrationRepository,
      OAuth2AuthorizedClientService authorizedClientService) throws Exception {
    http
        .cors(cors -> cors.configurationSource(corsConfigurationSource())) // Enable CORS
        .csrf(csrf -> csrf.disable()) // Disable CSRF
        .authorizeHttpRequests(auth -> auth
            .requestMatchers("/", "/oauth2/**", "/login/oauth2/**", "/api/auth/user")
            .permitAll() //Allow public login
            .requestMatchers("/internal/**")
            .permitAll() // Allow API Key authenticated requests without OAuth2
            .anyRequest().authenticated() // Require authentication for other endpoints
        )
        .addFilterBefore(apiKeyAuthFilter,
            UsernamePasswordAuthenticationFilter.class) // Apply API Key filter
        // Custom authentication entry point to return 401 for `/internal/**` instead of redirecting
        .sessionManagement(session -> session.disable())
        .exceptionHandling(ex -> ex
            .authenticationEntryPoint((request, response, authenticationException) -> {
              response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
            })
            .accessDeniedHandler((request, response, accessDeniedException) -> {
              response.setStatus(HttpServletResponse.SC_FORBIDDEN);
              response.getWriter().write("Forbidden: Access denied");
            })
        )
        .oauth2Login(oauth2 -> oauth2
            .tokenEndpoint(token -> token
                .accessTokenResponseClient(new StravaOAuth2AccessTokenResponseClient())
            )
            .successHandler(((request, response, authentication) -> {
              try {
                OAuth2AuthenticationToken oauthToken = (OAuth2AuthenticationToken) authentication;
                String userId = authentication.getName(); // This is the Strava user ID
                logger.info("OAuth Success: UserId={}", userId);

                // Generate JWT for frontend authentication
                String jwtToken = jwtUtils.generateToken(userId);

                // Send JWT in HTTP-only Cookie
                Cookie jwtCookie = new Cookie("TRAILMETRICS-JWT-TOKEN", jwtToken);
                jwtCookie.setHttpOnly(true);
                jwtCookie.setSecure(true);
                jwtCookie.setPath("/");
                response.addCookie(jwtCookie);

                response.sendRedirect(frontendUrl + "/dashboard");
              } catch (IOException e) {
                logger.error("Error generating JWT: {}", e.getMessage(), e);
                response.sendRedirect(frontendUrl + "/login?error=jwt_generation_failed");
              }

            }))

        );

    return http.build();
  }

  @Bean
  public OAuth2AuthorizedClientManager authorizedClientManager(
      ClientRegistrationRepository clientRegistrationRepository,
      OAuth2AuthorizedClientRepository authorizedClientRepository) {
    OAuth2AuthorizedClientProvider authorizedClientProvider = OAuth2AuthorizedClientProviderBuilder.builder()
        .authorizationCode()
        .refreshToken()
        .build();

    DefaultOAuth2AuthorizedClientManager authorizedClientManager = new DefaultOAuth2AuthorizedClientManager(
        clientRegistrationRepository, authorizedClientRepository
    );
    authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

    return authorizedClientManager;
  }

  @Bean
  public OAuth2AuthorizedClientRepository authorizedClientRepository(
      OAuth2AuthorizedClientService authorizedClientService) {
    return new AuthenticatedPrincipalOAuth2AuthorizedClientRepository(authorizedClientService);
  }

  @Bean
  public ClientRegistrationRepository clientRegistrationRepository() {

    ClientRegistration stravaRegistration = ClientRegistration.withRegistrationId("strava")
        .clientId(clientId)
        .clientSecret(clientSecret)
        .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
        .scope(scope)
        .authorizationUri(authorizationUri)
        .tokenUri(tokenUri)
        .redirectUri(redirectUri)
        .userInfoUri(userInfoUri)
        .userNameAttributeName(userNameAttributeName)
        .clientName(clientName)
        .build();

    return new InMemoryClientRegistrationRepository(List.of(stravaRegistration));
  }


  @Bean
  public CorsConfigurationSource corsConfigurationSource() {
    CorsConfiguration configuration = new CorsConfiguration();
    configuration.setAllowedOrigins(List.of(frontendUrl)); // Allow frontend
    configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
    configuration.setAllowedHeaders(List.of("*"));
    configuration.setAllowCredentials(true);

    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", configuration);
    return source;
  }
}